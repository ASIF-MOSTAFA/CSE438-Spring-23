import 'package:flutter/material.dart';
import 'package:flutter_chess_board/flutter_chess_board.dart';
//kazi Tamjeed Newaz	     Md Asif Mostafa	     Sameer Mahmud
//201014010	                 202014013	           201014063
//Group 3
//Chess Game App
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of the application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  ChessBoardController controller = ChessBoardController(); //gamelogic provided by this

  @override
  void initState() {
    super.initState();
    controller.addListener(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Chess Game"),
      ),
      body: Center(
        child: ChessBoard(
          controller: controller,
          boardColor: BoardColor.darkBrown,
          boardOrientation: PlayerColor.white,
          onMove: () {
            //
          },
          //this next part is if we would want arrows to be drawn on the board
          //arrow functionality can be added for on board analysis purposes
          //arrows: [
            //BoardArrow(from: "a2", to: "a3", color: Colors.red.withOpacity(0.9))
          //],
        ),
      ),
    );
  }
}
